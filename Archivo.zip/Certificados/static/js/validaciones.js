function mostrarPassword(){
    var obj = document.getElementById("password");
    obj.type = "text";
}

function ocultarPassword(){
    var obj = document.getElementById("password");
    obj.type = "password";
}

function mostrarConfirmPassword(){
    var obj = document.getElementById("confirmpassword");
    obj.type = "text";
}

function ocultarConfirmPassword(){
    var obj = document.getElementById("confirmpassword");
    obj.type = "password";
}